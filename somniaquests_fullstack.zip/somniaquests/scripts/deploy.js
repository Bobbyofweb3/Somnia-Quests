const hre = require("hardhat");

async function main() {
  const [deployer] = await hre.ethers.getSigners();

  console.log("Deploying contracts with:", deployer.address);

  const QuestToken = await hre.ethers.getContractFactory("QuestToken");
  const questToken = await QuestToken.deploy();
  await questToken.deployed();
  console.log("QuestToken deployed to:", questToken.address);

  const SomniaQuests = await hre.ethers.getContractFactory("SomniaQuests");
  const somniaQuests = await SomniaQuests.deploy();
  await somniaQuests.deployed();
  console.log("SomniaQuests deployed to:", somniaQuests.address);
}

main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
